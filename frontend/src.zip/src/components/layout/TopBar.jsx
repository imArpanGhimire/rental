import { useEffect, useMemo, useRef, useState } from "react";

import { createPortal } from "react-dom";

import { NavLink, useLocation, useNavigate } from "react-router-dom";

import {
  Bell,
  CalendarDays,
  Check,
  ChevronDown,
  Clock,
  LayoutDashboard,
  LogOut,
  Menu,
  Moon,
  Sun,
  UserCog,
  X,
} from "lucide-react";

import { useTranslation } from "react-i18next";

import Logo from "../ui/Logo";

import { useAuth } from "../../features/auth/AuthContext.jsx";

import { useTheme } from "../../context/ThemeContext.jsx";

import {
  useMyVisitRequests,
  useOwnerVisitRequests,
  useUpdateVisitRequestStatus,
} from "../../features/requests/hooks/useVisitRequests.js";

/* =========================================================
   LOGOUT MODAL
========================================================= */

function LogoutConfirmModal({ onConfirm, onCancel }) {
  return createPortal(
    <div
      className="
        fixed inset-0 z-[100000]
        flex items-center justify-center
        bg-black/40 px-4
        backdrop-blur-[5px]
      "
    >
      <div
        className="
          w-full max-w-[390px]
          overflow-hidden
          rounded-[26px]
          border border-black/[0.08]
          bg-[#f8f7f3]
          shadow-[0_28px_80px_rgba(20,23,31,0.24)]

          dark:border-white/[0.08]
          dark:bg-[#1b1d22]
        "
      >
        <div className="p-6 sm:p-7">
          <div
            className="
              flex h-10 w-10
              items-center justify-center
              rounded-xl
              border border-[#B5502E]/15
              bg-[#B5502E]/[0.07]
              text-[#B5502E]

              dark:border-[#e28a68]/15
              dark:bg-[#e28a68]/[0.08]
              dark:text-[#e28a68]
            "
          >
            <LogOut size={17} strokeWidth={1.8} />
          </div>

          <h2
            className="
              mt-5
              font-display
              text-[22px]
              font-bold
              tracking-[-0.035em]
              text-[#1f2125]

              dark:text-white
            "
          >
            Log out of Rentora?
          </h2>

          <p
            className="
              mt-2
              text-[13px]
              leading-6
              text-[#2b2d31]/50

              dark:text-white/45
            "
          >
            You'll need to log in again to access your account.
          </p>

          <div className="mt-7 flex items-center justify-end gap-2.5">
            <button
              type="button"
              onClick={onCancel}
              className="
                min-w-[88px]
                rounded-full
                border border-black/[0.10]
                bg-transparent
                px-5 py-2.5
                text-[12px]
                font-semibold
                text-[#26282d]
                transition-colors
                hover:bg-black/[0.04]

                dark:border-white/[0.10]
                dark:text-white/75
                dark:hover:bg-white/[0.06]
              "
            >
              Cancel
            </button>

            <button
              type="button"
              onClick={onConfirm}
              className="
                min-w-[88px]
                rounded-full
                bg-[#B5502E]
                px-5 py-2.5
                text-[12px]
                font-semibold
                text-white
                transition-colors
                hover:bg-[#9f4327]
                focus:outline-none
                focus:ring-2
                focus:ring-[#B5502E]/30

                dark:bg-[#c96340]
                dark:hover:bg-[#d3704c]
              "
            >
              Log out
            </button>
          </div>
        </div>
      </div>
    </div>,
    document.body,
  );
}

/* =========================================================
   NOTIFICATION STORAGE
========================================================= */

function getSeenNotificationKeys(userId) {
  if (!userId) {
    return new Set();
  }

  try {
    const stored = localStorage.getItem(`rentora-notifications-seen-${userId}`);

    if (!stored) {
      return new Set();
    }

    return new Set(JSON.parse(stored));
  } catch {
    return new Set();
  }
}

function saveSeenNotificationKeys(userId, keys) {
  if (!userId) {
    return;
  }

  try {
    localStorage.setItem(
      `rentora-notifications-seen-${userId}`,
      JSON.stringify([...keys]),
    );
  } catch {
    // Ignore localStorage errors.
  }
}

/* =========================================================
   LANGUAGE TOGGLE
========================================================= */

function LanguageToggle({ className = "" }) {
  const { i18n } = useTranslation();

  const currentLanguage = i18n.resolvedLanguage?.startsWith("ne") ? "ne" : "en";

  async function changeLanguage(language) {
    if (language === currentLanguage) {
      return;
    }

    document.documentElement.classList.add("language-switching");

    try {
      await i18n.changeLanguage(language);
    } finally {
      requestAnimationFrame(() => {
        requestAnimationFrame(() => {
          document.documentElement.classList.remove("language-switching");
        });
      });
    }
  }

  return (
    <div
      className={`
        flex
        h-10
        w-[128px]
        shrink-0
        items-center
        rounded-full
        border border-stone
        bg-bg
        p-1
        ${className}
      `}
    >
      <button
        type="button"
        onClick={() => changeLanguage("en")}
        className={`
          flex h-8 flex-1
          items-center
          justify-center
          rounded-full
          text-[11px]
          font-semibold
          transition-colors

          ${
            currentLanguage === "en"
              ? "bg-ink text-ivory"
              : "text-ink/45 hover:text-ink"
          }
        `}
      >
        EN
      </button>

      <button
        type="button"
        onClick={() => changeLanguage("ne")}
        className={`
          flex h-8 flex-1
          items-center
          justify-center
          rounded-full
          text-[11px]
          font-semibold
          transition-colors

          ${
            currentLanguage === "ne"
              ? "bg-ink text-ivory"
              : "text-ink/45 hover:text-ink"
          }
        `}
      >
        नेपा
      </button>
    </div>
  );
}

/* =========================================================
   THEME
========================================================= */

function ThemeToggleButton({ className = "" }) {
  const { theme, toggleTheme } = useTheme();

  const isDark = theme === "dark";

  return (
    <button
      type="button"
      onClick={toggleTheme}
      aria-label={isDark ? "Switch to light mode" : "Switch to dark mode"}
      title={isDark ? "Switch to light mode" : "Switch to dark mode"}
      className={`
        flex h-10 w-10
        items-center
        justify-center
        rounded-full
        border border-stone
        bg-bg
        text-ink/55
        transition-colors
        hover:border-ink/20
        hover:bg-ivory
        hover:text-ink
        ${className}
      `}
    >
      {isDark ? (
        <Sun size={16} strokeWidth={1.8} />
      ) : (
        <Moon size={16} strokeWidth={1.8} />
      )}
    </button>
  );
}

/* =========================================================
   VISIT REQUEST DETAILS
========================================================= */

function VisitRequestDetailsModal({ request, onClose }) {
  const property = request?.property;

  const renter = request?.renter;

  /*
   * ListingDetail currently sends visit data as:
   *
   * Preferred date: 2026-09-18 |
   * Preferred time: 14:30 |
   * Optional renter message
   *
   * Split those pieces so the owner sees a much
   * cleaner details modal.
   */
  const parts = String(request?.message || "")
    .split("|")
    .map((part) => part.trim())
    .filter(Boolean);

  const datePart =
    parts.find((part) => part.toLowerCase().startsWith("preferred date:")) ||
    "";

  const timePart =
    parts.find((part) => part.toLowerCase().startsWith("preferred time:")) ||
    "";

  const renterMessage = parts
    .filter((part) => {
      const lower = part.toLowerCase();

      return (
        !lower.startsWith("preferred date:") &&
        !lower.startsWith("preferred time:")
      );
    })
    .join(" | ");

  const preferredDate = datePart.replace(/^preferred date:\s*/i, "").trim();

  const preferredTime = timePart.replace(/^preferred time:\s*/i, "").trim();

  function formatPreferredDate(value) {
    if (!value) {
      return "Not specified";
    }

    const date = new Date(`${value}T00:00:00`);

    if (Number.isNaN(date.getTime())) {
      return value;
    }

    return date.toLocaleDateString(undefined, {
      year: "numeric",
      month: "short",
      day: "numeric",
    });
  }

  function formatPreferredTime(value) {
    if (!value) {
      return "Not specified";
    }

    const match = value.match(/^(\d{1,2}):(\d{2})$/);

    if (!match) {
      return value;
    }

    const hours = Number(match[1]);

    const minutes = Number(match[2]);

    if (!Number.isFinite(hours) || !Number.isFinite(minutes)) {
      return value;
    }

    const date = new Date();

    date.setHours(hours, minutes, 0, 0);

    return date.toLocaleTimeString(undefined, {
      hour: "numeric",
      minute: "2-digit",
    });
  }

  return createPortal(
    <div
      className="
        fixed inset-0
        z-[100000]
        flex items-center
        justify-center
        bg-black/45
        px-4
        backdrop-blur-[5px]
      "
      onMouseDown={onClose}
    >
      <div
        role="dialog"
        aria-modal="true"
        aria-labelledby="visit-request-title"
        className="
          w-full
          max-w-[440px]
          overflow-hidden
          rounded-[26px]
          border
          border-black/[0.08]
          bg-[#f8f7f3]
          shadow-[0_28px_80px_rgba(20,23,31,0.28)]

          dark:border-white/[0.08]
          dark:bg-[#1b1d22]
        "
        onMouseDown={(event) => event.stopPropagation()}
      >
        {/* HEADER */}

        <div className="border-b border-black/[0.07] px-6 py-5 dark:border-white/[0.07]">
          <div className="flex items-start justify-between gap-4">
            <div>
              <p className="text-[10px] font-semibold uppercase tracking-[0.15em] text-[#2b2d31]/40 dark:text-white/38">
                Visit request
              </p>

              <h2
                id="visit-request-title"
                className="mt-1 font-display text-[21px] font-bold tracking-[-0.035em] text-[#202226] dark:text-white"
              >
                Request details
              </h2>
            </div>

            <button
              type="button"
              onClick={onClose}
              className="
                flex h-8 w-8
                shrink-0
                items-center
                justify-center
                rounded-full
                border
                border-black/[0.07]
                bg-white/55
                text-[#2b2d31]/55
                transition-colors
                hover:bg-white
                hover:text-[#17191d]

                dark:border-white/[0.08]
                dark:bg-white/[0.05]
                dark:text-white/55
                dark:hover:bg-white/[0.09]
                dark:hover:text-white
              "
              aria-label="Close request details"
            >
              <X size={14} />
            </button>
          </div>
        </div>

        {/* CONTENT */}

        <div className="p-6">
          {/* PROPERTY */}

          <div>
            <p className="text-[10px] font-semibold uppercase tracking-[0.12em] text-[#2b2d31]/38 dark:text-white/35">
              Property
            </p>

            <p className="mt-1 text-[14px] font-semibold text-[#202226] dark:text-white">
              {property?.title ?? "Listing removed"}
            </p>

            {property?.location?.address && (
              <p className="mt-1 text-[11px] leading-5 text-[#2b2d31]/45 dark:text-white/40">
                {property.location.address}
              </p>
            )}
          </div>

          {/* RENTER */}

          <div className="mt-5">
            <p className="text-[10px] font-semibold uppercase tracking-[0.12em] text-[#2b2d31]/38 dark:text-white/35">
              Requested by
            </p>

            <p className="mt-1 text-[13px] font-semibold text-[#202226] dark:text-white">
              {renter?.name ?? "Renter"}
            </p>

            <div className="mt-1 flex flex-wrap items-center gap-x-2 gap-y-1 text-[11px] text-[#2b2d31]/48 dark:text-white/43">
              {renter?.phone && <span>{renter.phone}</span>}

              {renter?.phone && renter?.email && (
                <span className="text-[#2b2d31]/25 dark:text-white/20">·</span>
              )}

              {renter?.email && <span>{renter.email}</span>}
            </div>
          </div>

          {/* DATE / TIME */}

          <div className="mt-5 grid grid-cols-2 gap-3">
            <div
              className="
                rounded-[16px]
                border border-black/[0.07]
                bg-white/45
                p-3.5

                dark:border-white/[0.07]
                dark:bg-white/[0.035]
              "
            >
              <div className="flex items-center gap-1.5">
                <CalendarDays
                  size={12}
                  strokeWidth={1.8}
                  className="text-[#2b2d31]/40 dark:text-white/40"
                />

                <p className="text-[9px] font-semibold uppercase tracking-[0.11em] text-[#2b2d31]/38 dark:text-white/35">
                  Preferred date
                </p>
              </div>

              <p className="mt-2 text-[12px] font-semibold text-[#202226] dark:text-white">
                {formatPreferredDate(preferredDate)}
              </p>
            </div>

            <div
              className="
                rounded-[16px]
                border border-black/[0.07]
                bg-white/45
                p-3.5

                dark:border-white/[0.07]
                dark:bg-white/[0.035]
              "
            >
              <div className="flex items-center gap-1.5">
                <Clock
                  size={12}
                  strokeWidth={1.8}
                  className="text-[#2b2d31]/40 dark:text-white/40"
                />

                <p className="text-[9px] font-semibold uppercase tracking-[0.11em] text-[#2b2d31]/38 dark:text-white/35">
                  Preferred time
                </p>
              </div>

              <p className="mt-2 text-[12px] font-semibold text-[#202226] dark:text-white">
                {formatPreferredTime(preferredTime)}
              </p>
            </div>
          </div>

          {/* MESSAGE */}

          <div className="mt-5">
            <p className="text-[10px] font-semibold uppercase tracking-[0.12em] text-[#2b2d31]/38 dark:text-white/35">
              Renter message
            </p>

            <div
              className="
                mt-2
                rounded-[18px]
                border border-black/[0.07]
                bg-white/45
                px-4 py-4

                dark:border-white/[0.07]
                dark:bg-white/[0.035]
              "
            >
              {renterMessage ? (
                <p className="whitespace-pre-line text-[12px] leading-6 text-[#2b2d31]/68 dark:text-white/60">
                  {renterMessage}
                </p>
              ) : (
                <p className="text-[12px] leading-5 text-[#2b2d31]/38 dark:text-white/35">
                  No additional message was provided.
                </p>
              )}
            </div>
          </div>

          {/* REQUESTED DATE */}

          {request?.createdAt && (
            <p className="mt-4 text-[10px] text-[#2b2d31]/35 dark:text-white/30">
              Request sent {new Date(request.createdAt).toLocaleString()}
            </p>
          )}

          <div className="mt-6 flex justify-end">
            <button
              type="button"
              onClick={onClose}
              className="
                rounded-full
                bg-[#202226]
                px-5 py-2.5
                text-[11px]
                font-semibold
                text-white
                transition-colors
                hover:bg-[#303238]

                dark:bg-white
                dark:text-[#17191d]
                dark:hover:bg-white/90
              "
            >
              Close
            </button>
          </div>
        </div>
      </div>
    </div>,
    document.body,
  );
}

/* =========================================================
   NOTIFICATION PANEL
========================================================= */

function NotificationPanel({
  notifications,
  unreadCount,
  onMarkAllRead,
  onOpenNotification,
}) {
  const updateStatus = useUpdateVisitRequestStatus();

  const [updatingId, setUpdatingId] = useState(null);

  const [detailsRequest, setDetailsRequest] = useState(null);

  function handleRespond(event, requestId, status) {
    event.stopPropagation();

    if (!requestId || updateStatus.isPending) {
      return;
    }

    setUpdatingId(requestId);

    updateStatus.mutate(
      {
        id: requestId,
        status,
      },
      {
        onSettled: () => setUpdatingId(null),
      },
    );
  }

  function openDetails(event, request) {
    event.stopPropagation();

    if (!request) {
      return;
    }

    setDetailsRequest(request);
  }

  return (
    <>
      <div
        className="
          fixed
          left-4
          right-4
          top-[78px]
          z-[99999]
          w-auto
          max-w-none

          sm:absolute
          sm:left-auto
          sm:right-0
          sm:top-[calc(100%+10px)]
          sm:w-[360px]
          sm:max-w-[calc(100vw-24px)]
          overflow-hidden
          rounded-[22px]
          border border-black/10
          bg-gradient-to-b
          from-[#f3f2ee]
          via-[#ecebe7]
          to-[#dfded9]
          shadow-[0_24px_70px_rgba(20,23,31,0.18)]
          backdrop-blur-xl

          dark:border-white/10
          dark:from-[#1c1f26]
          dark:via-[#181b20]
          dark:to-[#121419]
        "
      >
        <div
          className="
            pointer-events-none
            absolute
            -right-16
            -top-20
            h-48 w-48
            rounded-full
            bg-white/55
            blur-3xl

            dark:bg-white/[0.035]
          "
        />

        {/* HEADER */}

        <div className="relative border-b border-black/10 px-4 pb-3.5 pt-4 dark:border-white/10">
          <div className="flex items-start justify-between gap-4">
            <div className="flex min-w-0 items-center gap-3">
              <div
                className="
                  flex h-9 w-9
                  shrink-0
                  items-center
                  justify-center
                  rounded-xl
                  border border-black/10
                  bg-white/55
                  text-[#26282d]
                  shadow-[0_8px_24px_rgba(20,23,31,0.07)]

                  dark:border-white/10
                  dark:bg-white/[0.06]
                  dark:text-white
                "
              >
                <Bell size={16} strokeWidth={1.8} />
              </div>

              <div>
                <p className="text-[10px] font-semibold uppercase tracking-[0.16em] text-[#2b2d31]/45 dark:text-white/40">
                  Activity
                </p>

                <h3 className="mt-0.5 font-display text-[17px] font-bold tracking-[-0.035em] text-[#1f2125] dark:text-white">
                  Notifications
                </h3>

                <p className="mt-0.5 text-[11px] leading-4 text-[#2b2d31]/55 dark:text-white/50">
                  {unreadCount > 0
                    ? `${unreadCount} unread notification${
                        unreadCount === 1 ? "" : "s"
                      }`
                    : "You're all caught up"}
                </p>
              </div>
            </div>

            {unreadCount > 0 && (
              <button
                type="button"
                onClick={onMarkAllRead}
                className="
                  shrink-0
                  rounded-full
                  border
                  border-black/10
                  bg-white/45
                  px-2.5 py-1.5
                  text-[10px]
                  font-semibold
                  text-[#2b2d31]/70
                  transition-colors
                  hover:bg-white/75
                  hover:text-[#14161a]

                  dark:border-white/10
                  dark:bg-white/[0.05]
                  dark:text-white/65
                  dark:hover:bg-white/10
                  dark:hover:text-white
                "
              >
                Mark all read
              </button>
            )}
          </div>
        </div>

        {/* LIST */}

        <div className="relative max-h-[calc(100vh-180px)] overflow-y-auto p-2.5 sm:max-h-[390px]">
          {notifications.length === 0 ? (
            <div
              className="
                rounded-[18px]
                border border-black/10
                bg-white/40
                px-6 py-9
                text-center

                dark:border-white/10
                dark:bg-white/[0.035]
              "
            >
              <Bell
                size={18}
                strokeWidth={1.8}
                className="mx-auto text-ink/35"
              />

              <p className="mt-3 text-[13px] font-semibold text-ink">
                No notifications
              </p>

              <p className="mt-1 text-[11px] text-ink/45">
                New activity will appear here.
              </p>
            </div>
          ) : (
            <div className="space-y-2">
              {notifications.map((notification) => {
                const isPending = notification.type === "pending";

                const request = notification.request;

                const requestId = request?._id;

                const isUpdating = updatingId === requestId;

                /*
                 * Pending notifications exist only for
                 * the owner, so only those get a details
                 * button.
                 */
                const canViewDetails = isPending && Boolean(request);

                return (
                  <div
                    key={notification.key}
                    className={`
                        relative
                        overflow-hidden
                        rounded-[17px]
                        border
                        px-3.5 py-3

                        ${
                          notification.unread
                            ? "border-black/10 bg-white/62 dark:border-white/10 dark:bg-white/[0.07]"
                            : "border-black/[0.07] bg-white/32 dark:border-white/[0.07] dark:bg-white/[0.025]"
                        }
                      `}
                  >
                    {notification.unread && (
                      <span className="absolute right-3.5 top-3.5 h-1.5 w-1.5 rounded-full bg-[#2f3136] dark:bg-white/70" />
                    )}

                    <div className="flex gap-3 pr-3">
                      <span
                        className={`
                            mt-0.5
                            flex h-9 w-9
                            shrink-0
                            items-center
                            justify-center
                            rounded-xl
                            border

                            ${
                              notification.type === "accepted"
                                ? "border-emerald-700/10 bg-emerald-50/80 text-emerald-700 dark:border-emerald-400/15 dark:bg-emerald-400/10 dark:text-emerald-300"
                                : notification.type === "declined"
                                  ? "border-red-700/10 bg-red-50/80 text-red-700 dark:border-red-400/15 dark:bg-red-400/10 dark:text-red-300"
                                  : "border-black/10 bg-white/60 text-[#2b2d31] dark:border-white/10 dark:bg-white/[0.06] dark:text-white/75"
                            }
                          `}
                      >
                        {notification.type === "accepted" ? (
                          <Check size={16} strokeWidth={2} />
                        ) : notification.type === "declined" ? (
                          <X size={16} strokeWidth={2} />
                        ) : (
                          <CalendarDays size={16} strokeWidth={1.8} />
                        )}
                      </span>

                      <div className="min-w-0 flex-1">
                        <button
                          type="button"
                          onClick={() => onOpenNotification(notification)}
                          className="block w-full text-left"
                        >
                          <span className="block pr-3 text-[12.5px] font-semibold leading-[1.35rem] text-[#202226] dark:text-white/90">
                            {notification.title}
                          </span>

                          <span className="mt-1 block text-[12px] leading-[1.55] text-[#2b2d31]/58 dark:text-white/50">
                            {notification.message}
                          </span>

                          <span className="mt-2.5 flex items-center gap-1.5 text-[10px] font-medium text-[#2b2d31]/38 dark:text-white/35">
                            <Clock size={10} strokeWidth={1.8} />

                            {notification.date}
                          </span>
                        </button>

                        {/* REQUEST DETAILS */}

                        {canViewDetails && (
                          <button
                            type="button"
                            onClick={(event) => openDetails(event, request)}
                            className="
                                mt-3
                                inline-flex
                                items-center
                                gap-1.5
                                rounded-full
                                border border-black/[0.08]
                                bg-white/45
                                px-3 py-1.5
                                text-[10px]
                                font-semibold
                                text-[#2b2d31]/65
                                transition-colors
                                hover:bg-white/80
                                hover:text-[#17191d]

                                dark:border-white/[0.08]
                                dark:bg-white/[0.04]
                                dark:text-white/60
                                dark:hover:bg-white/[0.08]
                                dark:hover:text-white
                              "
                          >
                            View request details
                          </button>
                        )}

                        {/* ACCEPT / DECLINE */}

                        {isPending && (
                          <div className="mt-3.5 grid grid-cols-2 gap-2.5">
                            <button
                              type="button"
                              disabled={isUpdating}
                              onClick={(event) =>
                                handleRespond(event, requestId, "accepted")
                              }
                              className="
                                  rounded-xl
                                  bg-[#202226]
                                  px-2.5
                                  py-1.5
                                  text-[10px]
                                  font-semibold
                                  text-white
                                  transition-colors
                                  hover:bg-[#303238]
                                  disabled:cursor-not-allowed
                                  disabled:opacity-50

                                  dark:bg-white
                                  dark:text-[#16181c]
                                  dark:hover:bg-white/90
                                "
                            >
                              {isUpdating ? "..." : "Accept"}
                            </button>

                            <button
                              type="button"
                              disabled={isUpdating}
                              onClick={(event) =>
                                handleRespond(event, requestId, "declined")
                              }
                              className="
                                  rounded-xl
                                  border
                                  border-black/10
                                  bg-white/45
                                  px-3 py-2
                                  text-[11px]
                                  font-semibold
                                  text-[#2b2d31]/70
                                  transition-colors
                                  hover:bg-white/75
                                  hover:text-[#14161a]
                                  disabled:cursor-not-allowed
                                  disabled:opacity-50

                                  dark:border-white/10
                                  dark:bg-white/[0.04]
                                  dark:text-white/65
                                  dark:hover:bg-white/[0.08]
                                  dark:hover:text-white
                                "
                            >
                              {isUpdating ? "..." : "Decline"}
                            </button>
                          </div>
                        )}
                      </div>
                    </div>
                  </div>
                );
              })}
            </div>
          )}
        </div>
      </div>

      {detailsRequest && (
        <VisitRequestDetailsModal
          request={detailsRequest}
          onClose={() => setDetailsRequest(null)}
        />
      )}
    </>
  );
}

/* =========================================================
   TOP BAR
========================================================= */

export default function TopBar() {
  const { user, role, isAuthenticated, isLoading, logout } = useAuth();

  const { t } = useTranslation();

  const navigate = useNavigate();

  const location = useLocation();

  const [confirmOpen, setConfirmOpen] = useState(false);

  const [menuOpen, setMenuOpen] = useState(false);

  const [notificationsOpen, setNotificationsOpen] = useState(false);

  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  const [seenKeys, setSeenKeys] = useState(() =>
    getSeenNotificationKeys(user?.id || user?._id),
  );

  const menuRef = useRef(null);

  const notificationRef = useRef(null);

  const userId = user?.id || user?._id;

  /* =======================================================
     VISIT REQUEST QUERIES
  ======================================================= */

  const ownerRequestsQuery = useOwnerVisitRequests({
    enabled: isAuthenticated && role === "owner",
  });

  const renterRequestsQuery = useMyVisitRequests({
    enabled: isAuthenticated && role === "renter",
  });

  const ownerRequests = role === "owner" ? ownerRequestsQuery.requests : [];

  const renterRequests = role === "renter" ? renterRequestsQuery.requests : [];

  /* =======================================================
     SEEN NOTIFICATIONS
  ======================================================= */

  useEffect(() => {
    setSeenKeys(getSeenNotificationKeys(userId));
  }, [userId]);

  /* =======================================================
     OUTSIDE CLICK
  ======================================================= */

  useEffect(() => {
    function handleOutsideClick(event) {
      if (menuRef.current && !menuRef.current.contains(event.target)) {
        setMenuOpen(false);
      }

      if (
        notificationRef.current &&
        !notificationRef.current.contains(event.target)
      ) {
        setNotificationsOpen(false);
      }
    }

    document.addEventListener("mousedown", handleOutsideClick);

    return () => {
      document.removeEventListener("mousedown", handleOutsideClick);
    };
  }, []);

  /* =======================================================
     CLOSE MOBILE MENU AFTER ROUTE CHANGE
  ======================================================= */

  useEffect(() => {
    setMobileMenuOpen(false);
  }, [location.pathname]);

  /* =======================================================
     MOBILE BODY LOCK
  ======================================================= */

  useEffect(() => {
    if (!mobileMenuOpen) {
      document.body.style.overflow = "";

      return;
    }

    document.body.style.overflow = "hidden";

    return () => {
      document.body.style.overflow = "";
    };
  }, [mobileMenuOpen]);

  /* =======================================================
     NOTIFICATIONS
  ======================================================= */

  const notifications = useMemo(() => {
    if (!isAuthenticated) {
      return [];
    }

    if (role === "owner") {
      return ownerRequests
        .map((request) => {
          const propertyTitle = request.property?.title || "your property";

          const renterName = request.renter?.name || "A renter";

          const key = `owner:${request._id}:${request.status}`;

          return {
            key,

            type:
              request.status === "accepted"
                ? "accepted"
                : request.status === "declined"
                  ? "declined"
                  : "pending",

            title:
              request.status === "pending"
                ? "New visit request"
                : `Visit request ${request.status}`,

            message: `${renterName} requested a visit for ${propertyTitle}.`,

            date: request.createdAt
              ? new Date(request.createdAt).toLocaleDateString()
              : "Recently",

            unread: !seenKeys.has(key),

            request,
          };
        })
        .sort(
          (a, b) =>
            new Date(b.request.createdAt || 0) -
            new Date(a.request.createdAt || 0),
        );
    }

    if (role === "renter") {
      return renterRequests
        .filter(
          (request) =>
            request.status === "accepted" || request.status === "declined",
        )
        .map((request) => {
          const propertyTitle =
            request.property?.title || "your requested property";

          const key = `renter:${request._id}:${request.status}`;

          return {
            key,

            type: request.status,

            title:
              request.status === "accepted"
                ? "Visit request accepted"
                : "Visit request declined",

            message: `Your visit request for ${propertyTitle} was ${request.status}.`,

            date: request.createdAt
              ? new Date(request.createdAt).toLocaleDateString()
              : "Recently",

            unread: !seenKeys.has(key),

            request,
          };
        })
        .sort(
          (a, b) =>
            new Date(b.request.createdAt || 0) -
            new Date(a.request.createdAt || 0),
        );
    }

    return [];
  }, [isAuthenticated, role, ownerRequests, renterRequests, seenKeys]);

  const unreadCount = notifications.filter(
    (notification) => notification.unread,
  ).length;

  function markAllNotificationsRead() {
    const next = new Set(seenKeys);

    notifications.forEach((notification) => {
      next.add(notification.key);
    });

    setSeenKeys(next);

    saveSeenNotificationKeys(userId, next);
  }

  function openNotification(notification) {
    const next = new Set(seenKeys);

    next.add(notification.key);

    setSeenKeys(next);

    saveSeenNotificationKeys(userId, next);

    setNotificationsOpen(false);

    const propertyId = notification.request?.property?._id;

    if (propertyId) {
      navigate(`/listings/${propertyId}`);

      return;
    }

    if (role === "owner") {
      navigate("/owner");
    } else {
      navigate("/renter");
    }
  }

  /* =======================================================
     LOGOUT
  ======================================================= */

  const handleLogout = async () => {
    try {
      await logout();
    } finally {
      setConfirmOpen(false);

      setMenuOpen(false);

      setNotificationsOpen(false);

      setMobileMenuOpen(false);

      navigate("/", {
        replace: true,
      });
    }
  };

  /* =======================================================
     NAV ITEMS
  ======================================================= */

  /*
   * "/" is the role-aware landing page.
   * "/browse" is the listing browser.
   */
  const navItems = [
    {
      to: "/browse",
      label: t("nav.browse", "Browse"),
    },

    ...(role === "owner"
      ? [
          {
            to: "/owner/listings",
            label: t("nav.myListings", "My Listings"),
          },
          {
            to: "/owner/listings/new",
            label: t("nav.addListing", "Add Listing"),
          },
        ]
      : []),

    ...(role === "renter"
      ? [
          {
            to: "/renter/saved",
            label: t("nav.saved", "Saved"),
          },
        ]
      : []),
  ];

  const initials = user?.name
    ? user.name
        .split(" ")
        .map((name) => name[0])
        .slice(0, 2)
        .join("")
        .toUpperCase()
    : "";

  function toggleMobileMenu() {
    setMobileMenuOpen((value) => !value);

    setMenuOpen(false);

    setNotificationsOpen(false);
  }

  return (
    <>
      <header
        className="
          sticky top-0
          z-[9999]
          border-b
          border-stone/80
          bg-bg/95
          backdrop-blur-xl
        "
      >
        <div
          className="
            mx-auto
            flex
            h-[68px]
            w-full
            max-w-[1280px]
            items-center
            gap-4
            px-4

            sm:px-6
            md:h-[72px]
          "
        >
          {/* LOGO */}

          <div className="flex min-w-0 items-center">
            <NavLink
              to="/"
              onClick={() => setMobileMenuOpen(false)}
              className="
                group
                flex
                shrink-0
                items-center
                text-ink
                no-underline
              "
            >
              <Logo />
            </NavLink>
          </div>

          {/* DESKTOP NAV */}

          <nav
            className="
              ml-4
              hidden
              items-center
              gap-1
              rounded-full
              border
              border-stone/70
              bg-bg/70
              p-1

              md:flex
            "
          >
            {navItems.map((item) => (
              <NavLink
                key={item.to}
                to={item.to}
                className={({ isActive }) =>
                  `relative rounded-full px-4 py-2 text-[13px] font-medium no-underline transition-colors ${
                    isActive
                      ? "bg-ink text-ivory shadow-sm"
                      : "text-ink/55 hover:bg-ivory hover:text-ink"
                  }`
                }
              >
                {item.label}
              </NavLink>
            ))}
          </nav>

          {/* RIGHT */}

          <div className="ml-auto flex items-center gap-1.5 sm:gap-2">
            <ThemeToggleButton className="hidden sm:flex" />

            <LanguageToggle className="hidden sm:flex" />

            {isLoading ? (
              <>
                <div className="h-10 w-10 animate-pulse rounded-full bg-ivory" />

                <div className="h-10 w-24 animate-pulse rounded-full bg-ivory" />
              </>
            ) : isAuthenticated ? (
              <>
                {/* NOTIFICATIONS */}

                <div className="relative" ref={notificationRef}>
                  <button
                    type="button"
                    aria-label="Notifications"
                    aria-expanded={notificationsOpen}
                    onClick={() => {
                      setNotificationsOpen((value) => !value);

                      setMenuOpen(false);

                      setMobileMenuOpen(false);
                    }}
                    className={`
                      relative
                      flex h-10 w-10
                      items-center
                      justify-center
                      rounded-full
                      border
                      transition-colors

                      ${
                        notificationsOpen
                          ? "border-ink/20 bg-ink text-ivory"
                          : "border-stone bg-bg text-ink/55 hover:bg-ivory hover:text-ink"
                      }
                    `}
                  >
                    <Bell size={17} strokeWidth={1.8} />

                    {unreadCount > 0 && (
                      <span className="absolute -right-0.5 -top-0.5 flex min-h-[17px] min-w-[17px] items-center justify-center rounded-full border-2 border-bg bg-brass px-1 text-[9px] font-bold leading-none text-ivory">
                        {unreadCount > 9 ? "9+" : unreadCount}
                      </span>
                    )}
                  </button>

                  {notificationsOpen && (
                    <NotificationPanel
                      notifications={notifications}
                      unreadCount={unreadCount}
                      onMarkAllRead={markAllNotificationsRead}
                      onOpenNotification={openNotification}
                    />
                  )}
                </div>

                {/* PROFILE MENU */}

                <div className="relative hidden sm:block" ref={menuRef}>
                  <button
                    type="button"
                    onClick={() => {
                      setMenuOpen((value) => !value);

                      setNotificationsOpen(false);

                      setMobileMenuOpen(false);
                    }}
                    title={user?.name}
                    className={`
                      flex
                      items-center
                      gap-2
                      rounded-full
                      border
                      py-1
                      pl-1
                      pr-2
                      transition-colors

                      ${
                        menuOpen
                          ? "border-ink/20 bg-ivory"
                          : "border-transparent hover:border-stone hover:bg-ivory/60"
                      }
                    `}
                  >
                    {user?.profilePicture ? (
                      <img
                        src={user.profilePicture}
                        alt={user?.name || "Profile"}
                        className="
                          h-8 w-8
                          rounded-full
                          border
                          border-brass/30
                          object-cover
                        "
                      />
                    ) : (
                      <span
                        className="
                          flex h-8 w-8
                          items-center
                          justify-center
                          rounded-full
                          border
                          border-brass/30
                          bg-brass-light
                          text-[11px]
                          font-bold
                          tracking-wide
                          text-ink
                        "
                      >
                        {initials}
                      </span>
                    )}

                    <span className="hidden max-w-[100px] truncate text-[12px] font-medium text-ink/65 lg:block">
                      {user?.name}
                    </span>

                    <ChevronDown
                      size={13}
                      strokeWidth={2}
                      className={`
                        text-ink/35
                        transition-transform

                        ${menuOpen ? "rotate-180" : ""}
                      `}
                    />
                  </button>

                  {menuOpen && (
                    <div
                      className="
                        absolute
                        right-0
                        top-[calc(100%+10px)]
                        z-[99999]
                        w-[278px]
                        max-w-[calc(100vw-24px)]
                        overflow-hidden
                        rounded-[22px]
                        border
                        border-black/[0.08]
                        bg-gradient-to-b
                        from-[#f3f2ee]
                        via-[#ebeae6]
                        to-[#dfded9]
                        shadow-[0_24px_70px_rgba(20,23,31,0.17)]
                        backdrop-blur-xl

                        dark:border-white/[0.08]
                        dark:from-[#1c1f26]
                        dark:via-[#181b20]
                        dark:to-[#121419]
                      "
                    >
                      {/* ACCOUNT */}

                      <div className="relative overflow-hidden border-b border-black/[0.06] px-4 py-4 dark:border-white/[0.07]">
                        <div className="pointer-events-none absolute -right-8 -top-10 h-24 w-24 rounded-full bg-white/45 blur-2xl dark:bg-white/[0.025]" />

                        <p className="relative text-[9px] font-semibold uppercase tracking-[0.16em] text-[#2b2d31]/38 dark:text-white/35">
                          Account
                        </p>

                        <div className="relative mt-3 flex items-center gap-3">
                          {user?.profilePicture ? (
                            <img
                              src={user.profilePicture}
                              alt={user?.name || "Profile"}
                              className="
                                h-11
                                w-11
                                shrink-0
                                rounded-[14px]
                                border
                                border-black/[0.08]
                                object-cover
                                shadow-[0_8px_22px_rgba(20,23,31,0.08)]

                                dark:border-white/[0.09]
                                dark:shadow-none
                              "
                            />
                          ) : (
                            <span
                              className="
                                flex
                                h-11
                                w-11
                                shrink-0
                                items-center
                                justify-center
                                rounded-[14px]
                                border
                                border-black/[0.07]
                                bg-white/55
                                text-xs
                                font-bold
                                text-[#202226]

                                dark:border-white/[0.08]
                                dark:bg-white/[0.05]
                                dark:text-white
                              "
                            >
                              {initials}
                            </span>
                          )}

                          <div className="min-w-0 flex-1">
                            <p className="truncate font-display text-[14px] font-bold tracking-[-0.02em] text-[#202226] dark:text-white">
                              {user?.name}
                            </p>

                            <div className="mt-1 flex items-center gap-2">
                              <span className="rounded-full border border-black/[0.07] bg-white/45 px-2 py-0.5 text-[9px] font-semibold capitalize text-[#2b2d31]/50 dark:border-white/[0.08] dark:bg-white/[0.035] dark:text-white/45">
                                {role}
                              </span>
                            </div>
                          </div>
                        </div>
                      </div>

                      {/* WORKSPACE */}

                      <div className="p-2.5">
                        <p className="px-2 pb-1.5 pt-0.5 text-[9px] font-semibold uppercase tracking-[0.14em] text-[#2b2d31]/32 dark:text-white/30">
                          Workspace
                        </p>

                        {/* DASHBOARD */}

                        <NavLink
                          to={`/${role}`}
                          onClick={() => setMenuOpen(false)}
                          className="
                            group
                            flex
                            items-center
                            gap-3
                            rounded-[15px]
                            px-2.5
                            py-2.5
                            text-[12px]
                            font-semibold
                            text-[#2b2d31]/66
                            no-underline
                            transition-colors
                            hover:bg-white/60
                            hover:text-[#17191d]

                            dark:text-white/60
                            dark:hover:bg-white/[0.055]
                            dark:hover:text-white
                          "
                        >
                          <span
                            className="
                              flex h-8 w-8
                              shrink-0
                              items-center
                              justify-center
                              rounded-xl
                              border
                              border-black/[0.06]
                              bg-white/50
                              text-[#2b2d31]/48

                              dark:border-white/[0.07]
                              dark:bg-white/[0.035]
                              dark:text-white/45
                            "
                          >
                            <LayoutDashboard size={14} strokeWidth={1.8} />
                          </span>

                          <span className="min-w-0 flex-1">
                            <span className="block">Dashboard</span>

                            <span className="mt-0.5 block text-[9px] font-medium text-[#2b2d31]/34 dark:text-white/30">
                              Open your workspace
                            </span>
                          </span>
                        </NavLink>

                        {/* PERSONAL INFORMATION */}

                        <NavLink
                          to={`/${role}/settings`}
                          onClick={() => setMenuOpen(false)}
                          className="
                            group
                            mt-1
                            flex
                            items-center
                            gap-3
                            rounded-[15px]
                            px-2.5
                            py-2.5
                            text-[12px]
                            font-semibold
                            text-[#2b2d31]/66
                            no-underline
                            transition-colors
                            hover:bg-white/60
                            hover:text-[#17191d]

                            dark:text-white/60
                            dark:hover:bg-white/[0.055]
                            dark:hover:text-white
                          "
                        >
                          <span
                            className="
                              flex h-8 w-8
                              shrink-0
                              items-center
                              justify-center
                              rounded-xl
                              border
                              border-black/[0.06]
                              bg-white/50
                              text-[#2b2d31]/48

                              dark:border-white/[0.07]
                              dark:bg-white/[0.035]
                              dark:text-white/45
                            "
                          >
                            <UserCog size={14} strokeWidth={1.8} />
                          </span>

                          <span className="min-w-0 flex-1">
                            <span className="block">Personal information</span>

                            <span className="mt-0.5 block text-[9px] font-medium text-[#2b2d31]/34 dark:text-white/30">
                              Profile and account details
                            </span>
                          </span>
                        </NavLink>

                        <div className="my-2 border-t border-black/[0.06] dark:border-white/[0.07]" />

                        {/* LOG OUT */}

                        <button
                          type="button"
                          onClick={() => {
                            setMenuOpen(false);

                            setConfirmOpen(true);
                          }}
                          className="
                            group
                            flex
                            w-full
                            items-center
                            gap-3
                            rounded-[15px]
                            px-2.5
                            py-2.5
                            text-left
                            text-[12px]
                            font-semibold
                            text-[#a4472a]
                            transition-colors
                            hover:bg-[#B5502E]/[0.065]

                            dark:text-[#e28a68]
                            dark:hover:bg-[#d97a54]/[0.09]
                          "
                        >
                          <span
                            className="
                              flex h-8 w-8
                              shrink-0
                              items-center
                              justify-center
                              rounded-xl
                              border
                              border-[#B5502E]/10
                              bg-[#B5502E]/[0.055]

                              dark:border-[#d97a54]/15
                              dark:bg-[#d97a54]/[0.07]
                            "
                          >
                            <LogOut size={14} strokeWidth={1.8} />
                          </span>

                          <span className="min-w-0 flex-1">
                            <span className="block">Log out</span>

                            <span className="mt-0.5 block text-[9px] font-medium text-current opacity-55">
                              Sign out of Rentora
                            </span>
                          </span>
                        </button>
                      </div>
                    </div>
                  )}
                </div>

                {/* MOBILE MENU BUTTON */}

                <button
                  type="button"
                  onClick={toggleMobileMenu}
                  className="
                    flex h-10 w-10
                    items-center
                    justify-center
                    rounded-full
                    border
                    border-stone
                    bg-bg
                    text-ink

                    md:hidden
                  "
                >
                  {mobileMenuOpen ? (
                    <X size={18} strokeWidth={1.8} />
                  ) : (
                    <Menu size={18} strokeWidth={1.8} />
                  )}
                </button>
              </>
            ) : (
              <>
                {/* GUEST */}

                <NavLink
                  to="/login"
                  className="
                    rounded-full
                    px-3 py-2
                    text-[13px]
                    font-medium
                    text-ink/55
                    no-underline
                    transition-colors
                    hover:bg-ivory
                    hover:text-ink
                  "
                >
                  Log in
                </NavLink>

                <NavLink
                  to="/register"
                  className="
                    hidden
                    items-center
                    rounded-full
                    bg-ink
                    px-4
                    py-2.5
                    text-[13px]
                    font-semibold
                    text-ivory
                    no-underline
                    shadow-sm
                    transition-opacity
                    hover:opacity-90

                    sm:flex
                  "
                >
                  List your property
                </NavLink>

                <button
                  type="button"
                  onClick={toggleMobileMenu}
                  className="
                    flex h-10 w-10
                    items-center
                    justify-center
                    rounded-full
                    border
                    border-stone
                    bg-bg
                    text-ink

                    md:hidden
                  "
                >
                  {mobileMenuOpen ? (
                    <X size={18} strokeWidth={1.8} />
                  ) : (
                    <Menu size={18} strokeWidth={1.8} />
                  )}
                </button>
              </>
            )}
          </div>
        </div>
      </header>

      {/* =====================================================
          MOBILE NAVIGATION
      ===================================================== */}

      {mobileMenuOpen && (
        <>
          <button
            type="button"
            aria-label="Close mobile navigation"
            onClick={() => setMobileMenuOpen(false)}
            className="
              fixed
              inset-0
              top-[68px]
              z-[9997]
              bg-ink/10
              backdrop-blur-[2px]

              md:hidden
            "
          />

          <div
            className="
              absolute
              left-0
              right-0
              top-[68px]
              z-[9998]
              border-b
              border-stone
              bg-bg
              shadow-[0_20px_45px_rgba(20,20,26,0.12)]

              md:hidden
            "
          >
            <nav className="px-4 py-4 sm:px-6">
              <div className="mb-3 flex items-center justify-between gap-3">
                <LanguageToggle />

                <ThemeToggleButton />
              </div>

              <div className="space-y-1">
                {navItems.map((item) => (
                  <NavLink
                    key={item.to}
                    to={item.to}
                    onClick={() => setMobileMenuOpen(false)}
                    className={({ isActive }) =>
                      `flex min-h-[48px] items-center rounded-xl px-4 text-sm font-medium no-underline ${
                        isActive
                          ? "bg-ink font-semibold text-ivory"
                          : "text-ink/65 hover:bg-ivory hover:text-ink"
                      }`
                    }
                  >
                    {item.label}
                  </NavLink>
                ))}
              </div>

              {isAuthenticated && (
                <>
                  <div className="my-3 border-t border-stone" />

                  <div className="mb-1 flex items-center gap-3 rounded-xl px-4 py-3">
                    {user?.profilePicture ? (
                      <img
                        src={user.profilePicture}
                        alt={user?.name || "Profile"}
                        className="
                          h-9 w-9
                          rounded-xl
                          border
                          border-brass/30
                          object-cover
                        "
                      />
                    ) : (
                      <span
                        className="
                          flex h-9 w-9
                          items-center
                          justify-center
                          rounded-xl
                          border
                          border-brass/30
                          bg-brass-light
                          text-[10px]
                          font-bold
                          text-ink
                        "
                      >
                        {initials}
                      </span>
                    )}

                    <div className="min-w-0">
                      <p className="truncate text-sm font-semibold text-ink">
                        {user?.name}
                      </p>

                      <p className="mt-0.5 text-[11px] capitalize text-ink/40">
                        {role}
                      </p>
                    </div>
                  </div>

                  <NavLink
                    to={`/${role}`}
                    onClick={() => setMobileMenuOpen(false)}
                    className="
                      flex
                      min-h-[48px]
                      items-center
                      gap-3
                      rounded-xl
                      px-4
                      text-sm
                      font-medium
                      text-ink/65
                      no-underline
                      transition-colors
                      hover:bg-ivory
                      hover:text-ink
                    "
                  >
                    <LayoutDashboard size={17} strokeWidth={1.8} />
                    Dashboard
                  </NavLink>

                  <NavLink
                    to={`/${role}/settings`}
                    onClick={() => setMobileMenuOpen(false)}
                    className="
                      flex
                      min-h-[48px]
                      items-center
                      gap-3
                      rounded-xl
                      px-4
                      text-sm
                      font-medium
                      text-ink/65
                      no-underline
                      transition-colors
                      hover:bg-ivory
                      hover:text-ink
                    "
                  >
                    <UserCog size={17} strokeWidth={1.8} />
                    Personal information
                  </NavLink>

                  <button
                    type="button"
                    onClick={() => {
                      setMobileMenuOpen(false);

                      setConfirmOpen(true);
                    }}
                    className="
                      flex
                      min-h-[48px]
                      w-full
                      items-center
                      gap-3
                      rounded-xl
                      px-4
                      text-left
                      text-sm
                      font-medium
                      text-[#B5502E]
                      transition-colors
                      hover:bg-[#B5502E]/[0.06]
                    "
                  >
                    <LogOut size={17} strokeWidth={1.8} />
                    Log out
                  </button>
                </>
              )}

              {!isAuthenticated && (
                <>
                  <div className="my-3 border-t border-stone" />

                  <NavLink
                    to="/login"
                    onClick={() => setMobileMenuOpen(false)}
                    className="
                      flex
                      min-h-[48px]
                      items-center
                      justify-center
                      rounded-xl
                      border
                      border-stone
                      text-sm
                      font-medium
                      text-ink
                      no-underline
                      hover:bg-ivory
                    "
                  >
                    Log in
                  </NavLink>

                  <NavLink
                    to="/register"
                    onClick={() => setMobileMenuOpen(false)}
                    className="
                      mt-2
                      flex
                      min-h-[48px]
                      items-center
                      justify-center
                      rounded-xl
                      bg-ink
                      text-sm
                      font-semibold
                      text-ivory
                      no-underline
                    "
                  >
                    List your property
                  </NavLink>
                </>
              )}
            </nav>
          </div>
        </>
      )}

      {/* LOGOUT CONFIRMATION */}

      {confirmOpen && (
        <LogoutConfirmModal
          onConfirm={handleLogout}
          onCancel={() => setConfirmOpen(false)}
        />
      )}
    </>
  );
}
