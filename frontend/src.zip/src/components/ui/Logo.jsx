export default function Logo({
  name = "Thegana",
  variant = "dark",
  className = "",
}) {
  const isLight = variant === "light";

  return (
    <div
      className={`
        flex items-center gap-2.5
        ${isLight ? "text-ivory" : "text-ink"}
        ${className}
      `}
    >
      {/* THEGANA MARK */}
      <svg
        width="27"
        height="27"
        viewBox="0 0 28 28"
        fill="none"
        xmlns="http://www.w3.org/2000/svg"
        aria-hidden="true"
      >
        {/* Location pin */}
        <path
          d="M14 25C14 25 22 18.2 22 11.2C22 6.7 18.4 3 14 3C9.6 3 6 6.7 6 11.2C6 18.2 14 25 14 25Z"
          stroke="currentColor"
          strokeWidth="2"
          strokeLinecap="round"
          strokeLinejoin="round"
        />

        {/* Home */}
        <path
          d="M10.2 12.1L14 9L17.8 12.1"
          stroke="currentColor"
          strokeWidth="1.8"
          strokeLinecap="round"
          strokeLinejoin="round"
        />

        <path
          d="M11.3 11.4V16.1H16.7V11.4"
          stroke="currentColor"
          strokeWidth="1.8"
          strokeLinecap="round"
          strokeLinejoin="round"
        />

        {/* Door */}
        <path
          d="M13.1 16.1V13.8H14.9V16.1"
          stroke="currentColor"
          strokeWidth="1.5"
          strokeLinecap="round"
          strokeLinejoin="round"
        />
      </svg>

      {/* WORDMARK */}
      <span className="font-display text-lg font-bold tracking-[-0.025em]">
        {name}
      </span>
    </div>
  );
}
