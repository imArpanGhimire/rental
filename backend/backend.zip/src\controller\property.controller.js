// backend/src/controller/property.controller.js
const rentalmodel = require("../model/rental.model")
const cloudinary = require("../config/cloudinary")
const streamifier = require("streamifier")

function uploadBufferToCloudinary(buffer) {
    return new Promise((resolve, reject) => {
        const stream = cloudinary.uploader.upload_stream(
            { folder: "rentora/listings" },
            (error, result) => {
                if (error) return reject(error)
                resolve(result)
            }
        )
        streamifier.createReadStream(buffer).pipe(stream)
    })
}

async function uploadimage(req, res) {
    try {
        if (!req.file) {
            return res.status(400).json({ message: "No image file provided" })
        }
        const result = await uploadBufferToCloudinary(req.file.buffer)
        return res.status(201).json({
            url: result.secure_url,
            publicId: result.public_id,
        })
    }
    catch (e) {
        console.error(e)
        return res.status(500).json({ message: "Image upload failed" })
    }
}

async function createproperty(req, res) {
    const { title, description, type, price, images, location, amenities } = req.body
    const owner = req.user.id

    if (!title || !description || !type || !price || !owner || !location) {
        return res.status(400).json({
            message: "All the information are required except images"
        })
    }

    try {
        const property = await rentalmodel.create({ title, description, type, price, owner, location, images, amenities })

        return res.status(201).json({
            message: "Property has been added",
            property
        })
    }
    catch (e) {
        console.error(e)
        return res.status(400).json({
            message: "something went wrong on our side"
        })
    }
}

async function getallproperties(req, res) {
    const { minPrice, maxPrice, search, sort, page, limit } = req.query
    const filter = {}

    if (minPrice || maxPrice) {
        filter.price = {}
        if (minPrice) filter.price.$gte = Number(minPrice)
        if (maxPrice) filter.price.$lte = Number(maxPrice)
    }

    if (search) {
        filter.title = { $regex: search, $options: "i" }
    }

    let sortOption = {}
    if (sort === "price_asc") sortOption.price = 1
    else if (sort === "price_desc") sortOption.price = -1
    else if (sort === "newest") sortOption.createdAt = -1
    else if (sort === "oldest") sortOption.createdAt = 1

    const currentPage = Number(page) || 1
    const currentLimit = Number(limit) || 10
    const skip = (currentPage - 1) * currentLimit

    try {
        const allproperties = await rentalmodel.find(filter).sort(sortOption).skip(skip).limit(currentLimit).populate("owner", "name")
        const totalCount = await rentalmodel.countDocuments(filter)
        const totalPages = Math.ceil(totalCount / currentLimit)

        return res.status(200).json({
            properties: allproperties,
            pagination: {
                currentPage,
                totalPages,
                totalCount,
                limit: currentLimit
            }
        })
    }
    catch (e) {
        console.error(e)
        return res.status(500).json({
            message: "something went wrong on our side"
        })
    }
}

async function getoneproperty(req, res) {
    const { id } = req.params
    try {
        const property = await rentalmodel.findById(id).populate("owner", "name phone")

        if (!property) {
            return res.status(404).json({
                message: "Couldn't find that property"
            })
        }
        return res.status(200).json(property)
    }
    catch (e) {
        console.error(e)
        return res.status(500).json({
            message: "Internal server error"
        })
    }

}

async function updateproperty(req, res) {
    const { id } = req.params
    const { title, description, type, price, location, images, amenities } = req.body

    const propertyToEdit = req.property

    try {

        if (!id) {
            return res.status(404).json({
                message: "The property you are trying to update couldn't be found"
            })
        }


        if (!propertyToEdit) {
            return res.status(404).json({
                message: "property not found"
            })
        }


        if (title) propertyToEdit.title = title
        if (description) propertyToEdit.description = description
        if (type) propertyToEdit.type = type
        if (price) propertyToEdit.price = price
        if (location) propertyToEdit.location = location
        if (images) propertyToEdit.images = images
        if (amenities) propertyToEdit.amenities = amenities

        const updatedProperty = await propertyToEdit.save()

        return res.status(200).json({
            message: "property updated successfully",
            updatedProperty
        })
    }
    catch (e) {
        console.error(e)
        return res.status(500).json({
            message: "Internal server error"

        })
    }
}

async function deleteproperty(req, res) {
    const { id } = req.params

    try {
        const propToDelete = req.property

        if (!propToDelete) {
            return res.status(404).json({
                message: "Property couldn't be found to delete"
            })
        }

        if (propToDelete.images && propToDelete.images.length > 0) {
            await Promise.all(
                propToDelete.images.map((img) =>
                    cloudinary.uploader.destroy(img.publicId).catch((e) => {
                        console.error(`Failed to delete Cloudinary image ${img.publicId}:`, e)
                    })
                )
            )
        }

        const deletedProperty = await propToDelete.deleteOne()
        return res.status(200).json({
            message: "deleted property",
            propToDelete
        })
    }
    catch (e) {
        console.error(e)
        return res.status(500).json({
            message: "Internal server error"
        })
    }
}

async function getmyproperties(req, res) {

    try {
        const myproperties = await rentalmodel.find({ owner: req.user.id })

        return res.status(200).json({
            message: "Here are the listing of your properties",
            myproperties
        })
    }
    catch (e) {
        console.error(e)
        return res.status(500).json({
            message: "Internal server error"
        })
    }
}

async function getnearbyproperties(req, res) {
    const { lng, lat, radius, minPrice, maxPrice, search, sort, page, limit } = req.query

    if (!lng || !lat || !radius) {
        return res.status(400).json({
            message: "lng, lat, and radius are required"
        })
    }

    const filter = {
        location: {
            $geoWithin: {
                $centerSphere: [[Number(lng), Number(lat)], Number(radius) / 6378.1]
            }
        }
    }

    if (minPrice || maxPrice) {
        filter.price = {}
        if (minPrice) filter.price.$gte = Number(minPrice)
        if (maxPrice) filter.price.$lte = Number(maxPrice)
    }

    if (search) {
        filter.title = { $regex: search, $options: "i" }
    }

    let sortOption = {}
    if (sort === "price_asc") sortOption.price = 1
    else if (sort === "price_desc") sortOption.price = -1
    else if (sort === "newest") sortOption.createdAt = -1
    else if (sort === "oldest") sortOption.createdAt = 1

    const currentPage = Number(page) || 1
    const currentLimit = Number(limit) || 10
    const skip = (currentPage - 1) * currentLimit

    try {
        const nearbyproperties = await rentalmodel.find(filter).sort(sortOption).skip(skip).limit(currentLimit).populate("owner", "name")
        const totalCount = await rentalmodel.countDocuments(filter)
        const totalPages = Math.ceil(totalCount / currentLimit)

        return res.status(200).json({
            properties: nearbyproperties,
            pagination: {
                currentPage,
                totalPages,
                totalCount,
                limit: currentLimit
            }
        })
    }
    catch (e) {
        console.error(e)
        return res.status(500).json({
            message: "something went wrong on our side"
        })
    }
}

async function getpropertiesinpolygon(req, res) {
    const { polygon, minPrice, maxPrice, search, sort, page, limit } = req.body

    if (!polygon || !Array.isArray(polygon) || polygon.length < 4) {
        return res.status(400).json({
            message: "A closed polygon with at least 4 points is required"
        })
    }

    const filter = {
        location: {
            $geoWithin: {
                $geometry: {
                    type: "Polygon",
                    coordinates: [polygon]
                }
            }
        }
    }

    if (minPrice || maxPrice) {
        filter.price = {}
        if (minPrice) filter.price.$gte = Number(minPrice)
        if (maxPrice) filter.price.$lte = Number(maxPrice)
    }

    if (search) {
        filter.title = { $regex: search, $options: "i" }
    }

    let sortOption = {}
    if (sort === "price_asc") sortOption.price = 1
    else if (sort === "price_desc") sortOption.price = -1
    else if (sort === "newest") sortOption.createdAt = -1
    else if (sort === "oldest") sortOption.createdAt = 1

    const currentPage = Number(page) || 1
    const currentLimit = Number(limit) || 10
    const skip = (currentPage - 1) * currentLimit

    try {
        const propertiesinpolygon = await rentalmodel.find(filter).sort(sortOption).skip(skip).limit(currentLimit).populate("owner", "name")
        const totalCount = await rentalmodel.countDocuments(filter)
        const totalPages = Math.ceil(totalCount / currentLimit)

        return res.status(200).json({
            properties: propertiesinpolygon,
            pagination: {
                currentPage,
                totalPages,
                totalCount,
                limit: currentLimit
            }
        })
    }
    catch (e) {
        console.error(e)
        return res.status(500).json({
            message: "something went wrong on our side"
        })
    }
}

module.exports = {
    uploadimage,
    createproperty,
    getallproperties,
    getoneproperty,
    updateproperty,
    deleteproperty,
    getmyproperties,
    getnearbyproperties,
    getpropertiesinpolygon,
}
